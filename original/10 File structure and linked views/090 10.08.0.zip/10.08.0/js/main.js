/*
*    main.js
*    Mastering Data Visualization with D3.js
*    FreedomCorp Dashboard
*/

d3.json("data/calls.json").then(function(data){    
    console.log(data)
})